package controls;

import android.content.Context;
import android.util.TypedValue;
import android.widget.Button;

public class NumberButton extends android.support.v7.widget.AppCompatButton {

    private int number = 0;

    public int getNumber()
    {
        return number;
    }

    public void setNumber(int n)
    {
        this.number = n;
        this.setText(number + "");
    }

    public NumberButton(Context ctx)
    {
        super(ctx);
        setAutoSizeTextTypeUniformWithConfiguration(5,30,1, TypedValue.COMPLEX_UNIT_SP);
    }
}
