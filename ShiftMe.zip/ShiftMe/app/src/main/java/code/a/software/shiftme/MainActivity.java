package code.a.software.shiftme;

import android.content.res.Configuration;
import android.graphics.Point;
import android.graphics.drawable.ColorDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Display;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import controls.NumberButton;
import field.DynamicLayout;
import helpers.Helper;
import helpers.NumberHelper;

public class MainActivity extends AppCompatActivity {

    private RelativeLayout containerLayout = null;
    private TextView txtMoves = null;

    private boolean isGameOver = false;
    private int currentMoves = 0;
    private int currentDim = 0;
    private int[][] gameState;
    private List<Integer> combination;
    private ColorDrawable finishColor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        finishColor = new ColorDrawable(getColor(R.color.colorFinishRow));
        setContentView(R.layout.activity_main);

        Button btnGenerate = findViewById(R.id.btnGenerate);
        final Spinner txtDim = findViewById(R.id.cmbDimension);
        containerLayout = findViewById(R.id.containerLayout);
        txtMoves = findViewById(R.id.txtMoves);

        btnGenerate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                 int result = txtDim.getSelectedItemPosition() + 3;
                 currentDim = result;
                 generateField();
        }});
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putInt("dim", currentDim);
        outState.putInt("moves", currentMoves);
        outState.putBoolean("isGameOver", isGameOver);
        outState.putIntegerArrayList("combination", (ArrayList<Integer>)combination);

        for (int i = 0; i < currentDim; i++)
            outState.putIntArray("state" + i, gameState[i]);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        if (savedInstanceState == null)
            return;

        currentDim = savedInstanceState.getInt("dim");
        currentMoves = savedInstanceState.getInt("moves");
        isGameOver = savedInstanceState.getBoolean("isGameOver");
        combination = savedInstanceState.getIntegerArrayList("combination");

        if (gameState == null)
            gameState = new int[currentDim][currentDim];

        for (int i = 0; i < currentDim; i++) {
            int[] sub = savedInstanceState.getIntArray("state" + i);

            for (int y = 0; y < sub.length; y++) {
                gameState[i][y] = sub[y];
            }
        }

        containerLayout.post(new Runnable() {
            @Override
            public void run() {
                generateGameField(true);
                txtMoves.setText("Züge: " + currentMoves);
            }
        });
    }

    public void resetCombination()
    {
        generateGameField(false);
    }

    public void generateGameField(boolean restore)
    {
        int distance = 2;
        int screenWidth = containerLayout.getWidth();
        int screenHeight = containerLayout.getHeight();

        // Generate layout
        final DynamicLayout result = DynamicLayout.GenerateLayout(this, currentDim, distance, screenWidth, screenHeight, false);

        int xCounter = 0;
        int yCounter = 0;
        int coloring = -1;

        if (restore)
            coloring = Helper.calculateColoring(gameState);

        // Assign buttons
        for (int i = 0; i < currentDim * currentDim; i++)
        {
            final int currentNumber = (restore ? gameState[yCounter][xCounter++] : combination.get(i));
            if (!restore)
                gameState[yCounter][xCounter++] = currentNumber;

            final NumberButton nb = result.getButtons()[i];

            if ((i + 1) % currentDim == 0)
            {
                xCounter = 0;
                yCounter++;
            }

            if (currentNumber == 0)
                nb.setVisibility(View.INVISIBLE);
            else
                nb.setVisibility(View.VISIBLE);

            if (currentNumber <= coloring && coloring != -1)
                nb.setBackground(finishColor);

            nb.setNumber(currentNumber);
            nb.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    // Disable moving buttons if GameIsOver
                    if (isGameOver)
                        return;

                    int index = Helper.indexOf(result.getButtons(), nb);

                    // Check index in matrix
                    // index - 1
                    // index + 1
                    // index + dim
                    // index - dim

                    int[] indices = new int[] { index - 1, index +  1, index - currentDim, index + currentDim};
                    for (int dex : indices)
                    {
                        if (dex < 0 && dex > currentDim *  currentDim- 1)
                            continue;

                        int value = Helper.getValueOfMatrixByIndex(gameState, dex);
                        if (value != -1 && value == 0)
                        {
                            NumberButton nbSearched = result.getButtons()[dex];
                            NumberButton nbClicked = (NumberButton)view;

                            // Swap positions on screen
                            RelativeLayout.LayoutParams nbSearchedLayoutParams = (RelativeLayout.LayoutParams)nbSearched.getLayoutParams();
                            RelativeLayout.LayoutParams nbClickedLayoutParams = (RelativeLayout.LayoutParams)nbClicked.getLayoutParams();

                            int oldLeft = nbClickedLayoutParams.leftMargin;
                            int oldTop = nbClickedLayoutParams.topMargin;

                            nbClickedLayoutParams.leftMargin = nbSearchedLayoutParams.leftMargin;
                            nbClickedLayoutParams.topMargin = nbSearchedLayoutParams.topMargin;

                            nbSearchedLayoutParams.leftMargin = oldLeft;
                            nbSearchedLayoutParams.topMargin = oldTop;

                            result.getLayout().updateViewLayout(nbSearched, nbSearchedLayoutParams);
                            result.getLayout().updateViewLayout(nbClicked, nbClickedLayoutParams);

                            // Swap in button-array
                            result.getButtons()[dex] = nbClicked;
                            result.getButtons()[index] = nbSearched;

                            // Swap in matrix
                            Helper.swapMatrix(dex, index, gameState);

                            // Refresh coloring
                            int coloring = Helper.calculateColoring(gameState);
                            Button test = new  Button(MainActivity.this);

                            Arrays.stream(result.getButtons()).forEach(p -> p.setBackground(test.getBackground()));
                            Arrays.stream(result.getButtons()).filter(p -> p.getNumber() <= coloring).forEach(b -> b.setBackground(finishColor));

                            currentMoves++;
                            txtMoves.setText("Züge: " + currentMoves);

                            if (Helper.isMatrix123n(gameState))
                            {
                                isGameOver = true;
                                Toast.makeText(MainActivity.this, "Sie haben gewonnen!!!!", Toast.LENGTH_LONG).show();
                            }

                            break;
                        }
                    }


                }
            });
        }

        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.MATCH_PARENT);
        // Clear and then add the view
        containerLayout.removeAllViews();
        containerLayout.addView(result.getLayout());
    }

    public void generateField()
    {
        // Reset counters
        txtMoves.setText("Züge: 0");
        currentMoves = 0;
        isGameOver = false;

        // Load combinations
        final List<List<Integer>> currentCombinations = NumberHelper.GeneratePossibleCombinations(currentDim, 100);
        Collections.shuffle(currentCombinations);

        combination = currentCombinations.get(0);
        combination.add(0);

        // Create matrix
        gameState = new int[currentDim][currentDim];

        generateGameField(false);
    }
}
